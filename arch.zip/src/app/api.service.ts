import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  // this service will access
  // https://jsonplaceholder.typicode.com/users/1

  // we instantiate the HttpClient instance like this
  constructor(private http: HttpClient) { }

  // methods of this service
  getOneUser(whichUser = '1'): Observable<any> {
    // build the URL
    let url = `https://jsonplaceholder.typicode.com/users/${whichUser}`
    // make a request
    return this.http.get(url) // NB this is an Observable
  }

  // try to make a POST request
  getFromAPI() {
    // a sample API that handles POST requests
    let url = 'https://httpbin.org/post'

    let headers = new Headers();

    headers.append('Content-Type', 'application/json');
    headers.append('Accept', 'application/json');

    headers.append('Access-Control-Allow-Origin', 'http://localhost:3000');
    headers.append('Access-Control-Allow-Credentials', 'true');
    // headers.append('data', dataBundle)
    // headers.append('GET', 'POST', 'OPTIONS');

    // headers.append('Authorization', 'Basic ' + base64.encode(username + ":" + password));

  

    return this.http.post(url, headers)
    .pipe(
      catchError(this.handleError)
    );
  }

  // method to handle any http errors
  handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something unexpected happened');
  };



}
