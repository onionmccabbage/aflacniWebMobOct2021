import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private apiService:ApiService) { }

  ngOnInit(): void {
  }
  makePostCall(){
    let payload = {'item':'monitor', 'price':'200'}
    this.apiService.getFromAPI()
      .subscribe( (resp)=>{
        console.log(resp)
      } )
  }

}
