// "Content-Type:application/json, Accept:application/json, Access-Control-Request-Method:POST,Access-Control-Allow-Origin:*"


let newAlbum = {
    "artist": "Yaeow",
    "album_id": "10",
    "price": 12.99,
    "tracks": 11,
    "title": "I Need U"
};

fetch('https://tg1kms3jh8.execute-api.eu-west-1.amazonaws.com/Prod',
{
    method: "POST",
    body: JSON.stringify(newAlbum),
    headers: {"Content-type": "application/json; charset=UTF-8"}
})
.then(response => response.json())
.then(json => console.log(json))
.catch(err => console.log(err));