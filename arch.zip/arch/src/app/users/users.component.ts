import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor() { }
  // data model for this component
  // @Input lets us receive values from outside
  @Input() newUser = {} // we will receive new users as an object
  usersArr = [] // we start with an empty array
  ngOnInit(): void {
  }

}
