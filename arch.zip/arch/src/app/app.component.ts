import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'arch';
  data  = '' // an initial value
  // methods for this component
  handleDataEvent(evt:any){ // TypeSscript expecte us to declare a data type
    // here we handle the custom dataEvent coming from login compoent instances
    this.data = evt
  }
}
