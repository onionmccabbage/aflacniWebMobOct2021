import { Component } from '@angular/core';
import { ApiService } from './api.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'arch';
  data  = '' // an initial value
  receivedData = {} // ready for our API servie to populate
  // we need a constructor in order to instantiate our service
  constructor(private apiService:ApiService){}

  // methods for this component
  handleDataEvent(evt:any){ // TypeScript expecte us to declare a data type
    // here we handle the custom dataEvent coming from login compoent instances
    this.data = evt
  }
  makeServiceCall(){
    // here we send a parameter to our servive method and receive data from the remote API
    this.apiService.getOneUser('3').subscribe((apiData) => { this.receivedData = apiData });
  }
}
