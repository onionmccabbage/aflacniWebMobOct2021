import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-val',
  templateUrl: './val.component.html',
  styleUrls: ['./val.component.css']
})
export class ValComponent implements OnInit {

  // models for this component
  hero = {name:''}
  constructor() { }

  ngOnInit(): void {
  }

}
