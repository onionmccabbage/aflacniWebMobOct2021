import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  // this service will access
  // https://jsonplaceholder.typicode.com/users/1

  // we instantiate the HttpClient instance like this
  constructor(private http: HttpClient) { }

  // methods of this service
  getOneUser(whichUser = '1'): Observable<any> {
    // build the URL
    let url = `https://jsonplaceholder.typicode.com/users/${whichUser}`
    // make a request
    return this.http.get(url) // NB this is an Observable
  }
  // let url = 'https://92jpr1aipd.execute-api.eu-west-1.amazonaws.com/Prod/'

  // try to make a POST request
  getFromAPI() {
    let newAlbum = { // an object suitable for Nicks end-point
      "artist": "Nick the Noodle",
      "album_id": "14",
      "price": 12.99,
      "tracks": 11,
      "title": "Can't get it working without you"
    };
    let newAlbum_j = JSON.stringify(newAlbum) // we have JSON
    // let url = 'https://tg1kms3jh8.execute-api.eu-west-1.amazonaws.com/Prod' // Nicks end-points

    let duckPostBlob = { // an objcet for a different end-point
      "customerID": "F2698F36-C0E5-997B-F3D4-BC51C5BC62BD",
      "customerType": "PolicyHolder",
      "firstName": "Fiona",
      "surname": "Brown",
      "dateOfBirth": "Oct 10, 1943",
      "claimType": "Wellness",
      "claimStatus": "Pending",
      "dateofClaim": "Dec 14, 2003",
      "hospitalized": "No",
      "evidenceProvided": "No",
      "linktoEvidence": ""
    }
    let duckPostBlob_j = JSON.stringify(duckPostBlob) // yaaay - JSON!!
    let url = 'https://sgtsluywif.execute-api.eu-west-1.amazonaws.com/Prod/Claims'
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        // 'charset':'UTF-8', // careful - the server may actively DISLIKE these headers!!!
        // 'Accept':'application/json',
        // 'Access-Control-Allow-Origin':'http://localhost:4200',
      })
    }
    // return this.http.post(url, newAlbum_j, httpOptions) // Nicks end-pont
    return this.http.post(url, duckPostBlob_j, httpOptions)
      .pipe(
        catchError(this.handleError)
      );
  }

  // method to handle any http errors
  handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something unexpected happened');
  };



}
